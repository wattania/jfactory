# date2 was overridden by date.
# To be precise, date was overridden by date2,
# and date2 was renamed to date.

require 'date'
